
# EcoCart 🌱

EcoCart helps users make sustainable shopping choices by checking the eco-score of everyday products.

## How to Use

1. Type a product name like "shampoo bottle" or "plastic cutlery".
2. Get its eco-score, environmental issues, and a greener alternative.

Built with ❤️ using Streamlit.
